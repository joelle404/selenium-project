package com.joelle.animals;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

@Import(TestcontainersConfiguration.class)
@SpringBootTest
class AnimalsApplicationTests {

    private WebDriver driver;
    private AnimalPage animalPage;

    @BeforeEach
    public void setUp() {
        // Initialize your driver here based on the browser for each test
        // This could also be parameterized to avoid duplicate code.
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void FirefoxTest() {     
        // Initialize Firefox driver
        driver = new FirefoxDriver(); 
        runTest();
    }
 
    @Test
    public void ChromeTest() { 
        // Initialize Chrome driver
        driver = new ChromeDriver();
        runTest();
    }

    @Test
    public void EdgeDriverTest() {     
        // Initialize Edge driver
        driver = new EdgeDriver();
        runTest();
    }

    private void runTest() {
        driver.get("file:///C:/Users/HP-G9/Desktop/selenium project/animals/src/main/resources/index.html");

        // Initialize the AnimalPage object with the current WebDriver instance
        animalPage = new AnimalPage(driver);

        try {
            animalPage.clickDog();
            assertTrue(isAudioPlaying(), "Dog sound is not playing!");
        } catch (Exception e) {
            e.printStackTrace();
            fail("Test failed due to an exception: " + e.getMessage());
        }
    }

    private boolean isAudioPlaying() {
        JavascriptExecutor js = (JavascriptExecutor) driver;  // Get WebDriver instance for current thread
        Boolean isPlaying = (Boolean) js.executeScript(
            "var audio = document.getElementById('animal-sound');" +
            "return audio && !audio.paused;");
        return isPlaying != null && isPlaying;
    }
}
