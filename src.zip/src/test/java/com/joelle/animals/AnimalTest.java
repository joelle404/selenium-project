// package com.joelle.animals;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.openqa.selenium.WebDriver;
// import org.openqa.selenium.chrome.ChromeDriver;
// import org.openqa.selenium.JavascriptExecutor;

// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.junit.jupiter.api.Assertions.fail;
// import org.junit.jupiter.api.AfterEach;

// public class AnimalTest {
//     // Using ThreadLocal to ensure each test gets its own instance of WebDriver
//     private static ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();
//     private AnimalPage animalPage;

//     @BeforeEach
//     public void setUp() {
//         // Initialize the WebDriver for each thread (test case)
//         WebDriver driver = new ChromeDriver();
//         driverThreadLocal.set(driver);  // Assigning driver to the current thread
//         animalPage = new AnimalPage(driver);
//         driver.get("file:///C:/Users/HP-G9/Desktop/selenium%20project/meowmeow/src/main/resources/index.html");
//     }

//     @Test
//     public void testCatSound() {
//         try {
//             animalPage.clickCat();
//             assertTrue(isAudioPlaying(), "Cat sound is not playing!");
//         } catch (Exception e) {
//             e.printStackTrace();
//             fail("Test failed due to an exception: " + e.getMessage());
//         }
//     }

//     @Test
//     public void testDogSound() {
//         try {
//             animalPage.clickDog();
//             assertTrue(isAudioPlaying(), "Dog sound is not playing!");
//         } catch (Exception e) {
//             e.printStackTrace();
//             fail("Test failed due to an exception: " + e.getMessage());
//         }
//     }

//     // Add similar test cases for other animals if needed

//     private boolean isAudioPlaying() {
//         JavascriptExecutor js = (JavascriptExecutor) driverThreadLocal.get();  // Get WebDriver instance for current thread
//         // Execute JavaScript to check if the audio is playing
//         Boolean isPlaying = (Boolean) js.executeScript(
//             "var audio = document.getElementById('animal-sound');" +
//             "return audio && !audio.paused;");
//         return isPlaying != null && isPlaying;
//     }

//     @AfterEach
//     public void tearDown() {
//         WebDriver driver = driverThreadLocal.get();
//         if (driver != null) {
//             driver.quit();  // Close the browser after each test
//         }
//     }
// }
