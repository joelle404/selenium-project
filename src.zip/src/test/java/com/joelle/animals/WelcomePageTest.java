package com.joelle.animals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.opencsv.CSVReader;
import java.time.Duration;

import java.io.FileReader;
import java.util.List;

public class WelcomePageTest {
    WebDriver driver;

    // Data provider to fetch data from the CSV file
    @DataProvider(name = "name")
    public Object[][] getData() throws Exception {
        CSVReader reader = new CSVReader(new FileReader("src/main/resources/name.csv"));
        List<String[]> data = reader.readAll();
        Object[][] dataArray = new Object[data.size() - 1][1]; // Skip header row
        for (int i = 1; i < data.size(); i++) {
            dataArray[i - 1][0] = data.get(i)[0];
        }
        reader.close();
        return dataArray;
    }

    @Test(dataProvider = "name")
    public void testWelcomePage(String name) {
        // Set up WebDriver (e.g., ChromeDriver)
        driver = new ChromeDriver();
        driver.get("C:/Users/HP-G9/Desktop/laaast/lastchance/src/main/resources/welcome.html");

        // Enter the name and submit the form
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        // Wait for the main page to load and check the greeting
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Correct usage in Selenium 4.x
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("greeting")));

        String greeting = driver.findElement(By.id("greeting")).getText();
        assert greeting.equals("Hello, " + name + "!") : "Greeting mismatch";

        // Close the browser
        driver.quit();
    }
}
