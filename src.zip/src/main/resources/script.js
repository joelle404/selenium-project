let donkeyCounter = 0; // Counter to track donkey clicks
const maxDonkeys = 2;  // Number of donkeys to click
let clickedDonkeys = {}; // Object to track if a donkey image has already been clicked
let clapSoundPlayed = false; // Flag to track if the clap sound has already been played

function incrementCounter(donkeyId) {
  let newDonkeyId = donkeyId.substring(0, donkeyId.length - 1);  // Removes the last character

  playSoundAnd(newDonkeyId);  // Play the sound for the clicked donkey

  // Check if the donkey hasn't been clicked already
  if (!clickedDonkeys[donkeyId] && donkeyCounter < maxDonkeys) {
    // Mark the donkey as clicked
    clickedDonkeys[donkeyId] = true;

    // Increment the donkey counter
    donkeyCounter++;

    // Update the counter display
    document.getElementById("counter").textContent = `Donkeys clicked: ${donkeyCounter}/${maxDonkeys}`;

    // If both donkeys have been clicked and sound hasn't been played yet
    if (donkeyCounter === maxDonkeys && !clapSoundPlayed) {
      playSoundAnd('clap'); // Play the clap sound
      resetCounter(); // Reset counter after both donkeys are clicked and clap sound plays
    }
  }
}

// Reset the counter to 0 after both donkeys are clicked
function resetCounter() {
  setTimeout(() => {
    donkeyCounter = 0;
    clickedDonkeys = {};  // Reset the clicked donkeys object
    clapSoundPlayed = false; // Reset the flag for the next cycle
    document.getElementById("counter").textContent = `Donkeys clicked: 0/${maxDonkeys}`;
  }, 3000); // Wait 3 seconds after the clap sound before resetting
}

// Play the sound and navigate to the animal page
function playSoundAndNavigate(animal) {
  const audio = document.getElementById("animal-sound");
  audio.src = `sounds/${animal}-sound.mp3`; // Dynamically set audio source based on the animal clicked
  audio.play();

  // Wait for a brief moment before navigating to the page
  setTimeout(() => {
    window.location.href = `${animal}.html`;  // Navigate dynamically to the animal's page
  }, 2000); // 2-second delay to allow the sound to play
}

// Play the sound for any animal or event
function playSoundAnd(animal) {
  const audio = document.getElementById("animal-sound");
  audio.src = `sounds/${animal}-sound.mp3`; // Dynamically set audio source based on the animal clicked
  audio.play();
}
